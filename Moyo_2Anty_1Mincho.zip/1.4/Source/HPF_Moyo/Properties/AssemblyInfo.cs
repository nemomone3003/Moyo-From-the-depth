﻿using System;
using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyVersion("1.1.0.0")]
[assembly: AssemblyTitle("HPF")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("HPF")]
[assembly: AssemblyCopyright("Copyright ©  2020")]
[assembly: AssemblyTrademark("")]
[assembly: ComVisible(false)]
[assembly: Guid("f9216471-b84f-4709-bc29-b54c27efadd0")]
[assembly: AssemblyFileVersion("1.1.0.0")]
