﻿using RimWorld;
using Verse;

namespace HPF_Moyo
{
	public class HPFWorkGiverDef : WorkGiverDef
	{
		public JobDef harvestJobDef;
	}
}
