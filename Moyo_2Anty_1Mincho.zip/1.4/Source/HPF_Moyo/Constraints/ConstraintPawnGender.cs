﻿using Verse;

namespace HPF_Moyo
{
    public abstract class ConstraintPawnGender : Constraint
    {
        public Gender gender;
    }
}
