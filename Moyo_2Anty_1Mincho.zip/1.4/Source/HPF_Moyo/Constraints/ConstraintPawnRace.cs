﻿namespace HPF_Moyo
{
    public abstract class ConstraintPawnRace : Constraint
    {
        public string race;

        public bool humanlike;
    }
}
