﻿namespace HPF_Moyo
{
    public abstract class ConstraintPawnAge : Constraint
    {
        public int age;
    }
}
