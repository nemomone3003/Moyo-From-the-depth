﻿using Verse;

namespace HPF_Moyo
{
	public abstract class ConstraintPawnHediff : Constraint
	{
		public HediffDef hediff;
	}
}
